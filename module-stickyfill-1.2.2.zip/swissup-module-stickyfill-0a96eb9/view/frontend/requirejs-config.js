var config = {
    map: {
        '*': {
            'stickyfill': 'Swissup_Stickyfill/js/stickyfill'
        }
    }
};
