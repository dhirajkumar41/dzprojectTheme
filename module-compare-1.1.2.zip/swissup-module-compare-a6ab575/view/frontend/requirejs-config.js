var config = {
    map: {
        '*': {
            'compare': 'Swissup_Compare/js/compare'
        }
    }
};
