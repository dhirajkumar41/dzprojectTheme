<?php

namespace Swissup\QuantitySwitcher\Model\Config\Source;

class QtySwitcherType implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'arrows', 'label' => __('Arrows')],
            ['value' => 'dropdown', 'label' => __('Dropdown')],
        ];
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        $result = [];
        foreach ($this->toOptionArray() as $item) {
            $result[$item['value']] = $item['label'];
        }
        return $result;
    }
}
