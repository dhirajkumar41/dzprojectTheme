<?php

namespace Swissup\SeoImages\Model\ResourceModel;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Index extends AbstractDb
{
    /**
     * @var ProductRepositoryInterface;
     */
    private $productRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var int
     */
    private $batchSize;

    /**
     * @param ProductRepositoryInterface                        $productRepository
     * @param SearchCriteriaBuilder                             $searchCriteriaBuilder
     * @param int                                               $batchSize
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param string                                            $connectionName
     */
    public function __construct(
        ProductRepositoryInterface $productRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        $batchSize = 200,
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        $connectionName = null
    ) {
        $this->productRepository = $productRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->batchSize = $batchSize;
        parent::__construct($context, $connectionName);
    }

    /**
     * Model initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('swissup_seoimages_index', 'id');
    }

    /**
     * Delete indexes by product IDs.
     *
     * @param  array  $ids
     */
    public function deleteIndex(array $ids = [])
    {
        $whereClause = empty($ids)
            ? null // delete all when no product ids provided
            : ['entity_id IN (?)' => $ids];
        $this->getConnection()->delete($this->getMainTable(), $whereClause);

        return $this;
    }

    /**
     * Build indexes for product IDs.
     *
     * @param  array  $ids
     */
    public function saveIndex(array $ids = [])
    {
        if (empty($ids)) {
            $criteria = $this->searchCriteriaBuilder->create();
        } else {
            $criteria = $this->searchCriteriaBuilder
                ->addFilter('entity_id', implode(',', $ids), 'in')
                ->create();
        }

        $products = $this->productRepository->getList($criteria)->getItems();
        $data = [];
        $count = 0;
        foreach ($products as $product) {
            $count++;
            $images = $product->getData('media_gallery/images');
            $images = is_array($images) ? $images : [];
            foreach ($images as $image) {
                $data[] = [
                    'entity_id' => $product->getId(),
                    'file' => $image['file']
                ];
            }

            if ($count >= $this->batchSize) {
                $this->insertData($data);
                $data = [];
                $count = 0;
            }
        }

        $this->insertData($data);

        return $this;
    }

    /**
     * Count indexed images names.
     *
     * @return int
     */
    public function countImages()
    {
        $connection = $this->getConnection();
        $select = $connection
            ->select()
            ->from(
                $this->getMainTable(),
                'count(DISTINCT file, file)'
            );
        $data = $connection->fetchRow($select);

        return is_array($data) ? (int)reset($data) : 0;
    }

    /**
     * @param  array  &$data
     * @return $this
     */
    private function insertData(array &$data)
    {
        if (empty($data)) {
            return $this;
        }

        $this->getConnection()->insertMultiple($this->getMainTable(),$data);

        return $this;
    }
}
