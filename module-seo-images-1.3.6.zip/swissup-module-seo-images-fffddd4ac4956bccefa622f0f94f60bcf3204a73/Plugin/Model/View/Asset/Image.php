<?php

namespace Swissup\SeoImages\Plugin\Model\View\Asset;

class Image
{
    /**
     * @var \Swissup\SeoImages\Helper\Data
     */
    private $helper;

    /**
     * @var \Swissup\SeoImages\Model\FileResolver
     */
    private $fileResolver;

    /**
     * @param \Swissup\SeoImages\Helper\Data        $helper
     * @param \Swissup\SeoImages\Model\FileResolver $fileResolver
     */
    public function __construct(
        \Swissup\SeoImages\Helper\Data $helper,
        \Swissup\SeoImages\Model\FileResolver $fileResolver
    ) {
        $this->helper = $helper;
        $this->fileResolver = $fileResolver;
    }

    /**
     * After plugin.
     * Change destination path to resized image on server.
     *
     * @param  \Magento\Catalog\Model\View\Asset\Image $subject
     * @param  string                                  $result
     * @return string
     */
    public function afterGetPath(
        \Magento\Catalog\Model\View\Asset\Image $subject,
        $result
    ) {
        if (!$this->helper->canChangeName()) {
            return $result;
        }

        $originalFile = $subject->getFilePath();
        $targetFile = $this->fileResolver->getTargetFile($originalFile);
        if (!$targetFile) {
            return $result;
        }

        $newPath = str_replace($originalFile, $targetFile, $result);
        if (!$this->helper->isProduction()) {
            $fileKey = $this->helper->buildFileKey($newPath);
            $this->helper->saveSeoImage($fileKey, $originalFile, $targetFile);
        }

        return $newPath;
    }

    /**
     * Aftre plugin.
     * Change URL to resized image.
     *
     * @param  \Magento\Catalog\Model\View\Asset\Image $subject
     * @param  string                                  $result
     * @return string
     */
    public function afterGetUrl(
        \Magento\Catalog\Model\View\Asset\Image $subject,
        $result
    ) {
        if (!$this->helper->canChangeName()) {
            return $result;
        }

        $originalFile = $subject->getFilePath();
        $targetFile = $this->fileResolver->getTargetFile($originalFile);
        if (!$targetFile) {
            return $result;
        }

        $newUrl = str_replace($originalFile, $targetFile, $result);
        if (!$this->helper->isProduction()) {
            $fileKey = $this->helper->buildFileKey($newUrl);
            $this->helper->saveSeoImage($fileKey, $originalFile, $targetFile);
        }

        return $newUrl;
    }
}
