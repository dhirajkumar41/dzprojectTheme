<?php
namespace Swissup\Askit\Controller\Vote;

class Dec extends Inc
{
    /**
     * @var integer
     */
    protected $voteStep = -1;
}
