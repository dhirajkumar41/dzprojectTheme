<?php
namespace Swissup\Askit\Controller\Message;

abstract class SaveAbstract extends \Magento\Framework\App\Action\Action
{
    /**
     * Customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Swissup\Askit\Helper\Config
     */
    protected $configHelper;

    /**
     *
     * @var \Swissup\Askit\Model\MessageFactory
     */
    protected $messageFactory;


    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Swissup\Askit\Helper\Config $configHelper
     * @param \Swissup\Askit\Model\MessageFactory $messageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Swissup\Askit\Helper\Config $configHelper,
        \Swissup\Askit\Model\MessageFactory $messageFactory,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->customerSession = $customerSession;
        $this->storeManager = $storeManager;
        $this->configHelper = $configHelper;
        $this->messageFactory = $messageFactory;
        $this->formKeyValidator = $formKeyValidator;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    /**
     *
     */
    protected function redirectReferer()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setRefererOrBaseUrl();
        // $this->_redirect($this->_redirect->getRedirectUrl());
    }

    protected function validateFormKey()
    {
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(
                __('Your session has expired')
            );

            return false;
        }

        return true;
    }

    public function resultJson()
    {
        $messages = $this->messageManager->getMessages(true);
        $response = [];
        foreach ($messages->getItems() as $message) {
            $response['messages'][] = [
                'type' => $message->getType(),
                'text' => $message->getText()
            ];
        }

        $resultJson = $this->resultJsonFactory->create();

        return $resultJson->setData($response);
    }

    protected function validateData($data)
    {
        $error = false;
        $errorMessage = '';
        if (!\Zend_Validate::is(trim($data['customer_name']), 'NotEmpty')) {
            $error = true;
            $errorMessage = 'Name can\'t be empty.';
        }
        if (!\Zend_Validate::is(trim($data['text']), 'NotEmpty')) {
            $error = true;
            $errorMessage = 'Question can\'t be empty.';
        }
        if (!\Zend_Validate::is(trim($data['email']), 'EmailAddress')) {
            $error = true;
            $errorMessage = 'Email is not valid.';
        }

        if ($error) {
            throw new \Exception(__($errorMessage));
        }
    }
}
