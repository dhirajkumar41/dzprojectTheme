<?php

namespace Swissup\Askit\Controller\Question;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\ResultFactory;

class ListAjax extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Customer\Model\Session       $customerSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->customerSession = $customerSession;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $askitExpanded = $this->customerSession->getAskitExpanded();
        if ($askitExpanded !== null) {
            $this->getRequest()->setParam('expanded', $askitExpanded);
            $this->customerSession->unsAskitExpanded();
        }

        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_LAYOUT);
        return $resultPage;
    }
}
