<?php
namespace Swissup\Askit\Controller\Question;

class Save extends \Swissup\Askit\Controller\Message\SaveAbstract
{
    /**
     * Post user question
     *
     * @return void
     * @throws \Exception
     */
    public function execute()
    {
        $isAjax = $this->getRequest()->isXmlHttpRequest();
        if ($this->messageManager->getMessages()->getErrors()
            || !$this->validateFormKey()
        ) {
            return $isAjax
                ? $this->resultJson()
                : $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        $post = $this->getRequest()->getPostValue();

        if (!$post) {
            return $isAjax
                ? $this->resultJson()
                : $this->redirectReferer();
        }

        $isLoggedIn = $this->customerSession->isLoggedIn();
        $customer = $this->customerSession->getCustomer();
        $isAllowedGuestQuestion = $this->configHelper->isAllowedGuestQuestion();

        if (!$isLoggedIn && !$isAllowedGuestQuestion) {
            $this->messageManager->addError(__('Your must login'));
            return $isAjax
                ? $this->resultJson()
                : $this->redirectReferer();
        }

        try {
            $post['email'] = $isLoggedIn ? $customer->getEmail() : $post['email'];
            $post['customer_id'] = $isLoggedIn ? $customer->getId() : null;
            $post['store_id'] = $this->storeManager->getStore()->getId();
            $post['status'] = $this->configHelper->getDefaultQuestionStatus();

            $this->validateData($post);

            $model = $this->messageFactory->create();
            $model->setData($post);
            $model->save();

            $this->_eventManager->dispatch(
                'askit_message_after_save',
                ['message' => $model, 'request' => $this->getRequest()]
            );

            $this->messageManager->addSuccess(
                __('Thanks for contacting us with your question. We\'ll respond to you very soon.')
            );
        } catch (\Exception $e) {
            // $this->inlineTranslation->resume();
            $this->messageManager->addError(
                $e->getMessage()  . ' '. __('We can\'t process your request right now. Sorry, that\'s all we know.')
            );
        }

        return $isAjax
            ? $this->resultJson()
            : $this->redirectReferer();
    }
}
