<?php

namespace Swissup\Askit\Controller\Adminhtml\Message;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Registry;
use Swissup\Askit\Model\MessageFactory;

abstract class AbstractEdit extends \Magento\Backend\App\Action
{
    /**
     * @var MessageFactory
     */
    protected $messageFactory;

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var \Magento\Framework\Filter\FilterManager
     */
    protected $filterManager;

    /**
     * @param Context $context
     * @param MessageFactory $messageFactory
     * @param PageFactory $resultPageFactory
     * @param Registry $registry
     */
    public function __construct(
        Context $context,
        MessageFactory $messageFactory,
        PageFactory $resultPageFactory,
        Registry $registry,
        \Magento\Framework\Filter\FilterManager $filterManager
    ) {
        parent::__construct($context);
        $this->messageFactory = $messageFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->registry = $registry;
        $this->filterManager = $filterManager;
    }

    /**
     * @param  string $text
     * @return string
     */
    protected function getShortenedText($text, $maxLength = 90)
    {
        $text = $this->filterManager->stripTags(
            $text,
            ['allowableTags' => false, 'escape' => null]
        );
        $text = $this->filterManager->truncate(
            $text,
            ['length' => $maxLength, 'breakWords' => false, 'etc' => '...']
        );

        return $text;
    }
}
