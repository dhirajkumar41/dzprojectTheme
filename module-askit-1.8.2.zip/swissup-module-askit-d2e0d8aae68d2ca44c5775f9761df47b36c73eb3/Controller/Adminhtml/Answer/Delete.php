<?php

namespace Swissup\Askit\Controller\Adminhtml\Answer;

use Magento\Backend\App\Action\Context;
use Swissup\Askit\Model\MessageFactory as AnswerFactory;

class Delete extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Swissup_Askit::message_save';

    /**
     * @var AnswerFactory
     */
    protected $answerFactory;

    /**
     * @param Context $context
     * @param AnswerFactory $answerFactory
     */
    public function __construct(
        Context $context,
        AnswerFactory $answerFactory
    ) {
        $this->answerFactory = $answerFactory;
        parent::__construct($context);
    }

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $id = $this->getRequest()->getParam('id');
        $togridFlag = $this->getRequest()->getParam('togrid');
        if ($id) {
            try {
                $model = $this->answerFactory->create();
                $model->load($id);
                $questionId = $model->getParentId();
                $model->delete();
                $this->messageManager->addSuccess(__('The answer has been deleted.'));
                if ($togridFlag) {
                    return $resultRedirect->setPath('*/*/');
                }

                return $resultRedirect->setPath('askit/question/edit', ['id' => $questionId]);
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['answer_id' => $id]);
            }
        }
        $this->messageManager->addError(__('We can\'t find an answer to delete.'));

        return $resultRedirect->setPath('*/*/');
    }
}
