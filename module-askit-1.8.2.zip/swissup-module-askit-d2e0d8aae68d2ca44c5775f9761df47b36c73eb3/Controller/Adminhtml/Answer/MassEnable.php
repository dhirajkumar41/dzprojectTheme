<?php

namespace Swissup\Askit\Controller\Adminhtml\Answer;

class MassEnable extends \Swissup\Askit\Controller\Adminhtml\Message\MassEnable
{
    /**
     * @{inheritdocs}
     */
    protected function getCollection()
    {
        $collection = parent::getCollection();

        return $collection->addAnswerFilter();
    }
}
