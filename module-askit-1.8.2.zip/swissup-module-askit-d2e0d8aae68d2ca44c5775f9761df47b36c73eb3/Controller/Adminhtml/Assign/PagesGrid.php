<?php
namespace Swissup\Askit\Controller\Adminhtml\Assign;

class PagesGrid extends Pages
{
}
