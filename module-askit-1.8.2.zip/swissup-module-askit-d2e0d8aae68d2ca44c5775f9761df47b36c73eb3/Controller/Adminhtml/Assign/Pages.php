<?php
namespace Swissup\Askit\Controller\Adminhtml\Assign;

class Pages extends AbstractAction
{
    protected $listingBlockName = 'askit_question_assign_pages_listing';
}
