<?php
namespace Swissup\Askit\Controller\Adminhtml\Assign;

class Categories extends AbstractAction
{
    protected $listingBlockName = 'askit_question_assign_categories_listing';
}
