<?php
namespace Swissup\Askit\Controller\Adminhtml\Assign;

class ProductsGrid extends Products
{
}
