<?php
namespace Swissup\Askit\Controller\Adminhtml\Assign;

class CategoriesGrid extends Categories
{
}
