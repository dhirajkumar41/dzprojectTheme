<?php

namespace Swissup\Askit\Block\Question;

class Context implements \Magento\Framework\ObjectManager\ContextInterface
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Swissup\Askit\Helper\Config
     */
    protected $configHelper;

    /**
     * @var \Swissup\Askit\Helper\Url
     */
    protected $urlHelper;

    /**
     * @var \Swissup\Askit\Model\Vote\Factory
     */
    protected $voteFactory;

    /**
     * @var \Magento\Framework\View\Element\Template\Context
     */
    protected $originalContext;

    /**
     * @param \Magento\Framework\Registry                      $registry
     * @param \Magento\Customer\Model\SessionFactory           $customerSessionFactory
     * @param \Swissup\Askit\Helper\Config                     $configHelper
     * @param \Swissup\Askit\Helper\Url                        $urlHelper
     * @param \Magento\Framework\Data\Helper\PostHelper        $postDataHelper
     * @param \Swissup\Askit\Model\Vote\Factory                $voteFactory
     * @param \Magento\Framework\View\Element\Template\Context $context
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\SessionFactory $customerSessionFactory,
        \Swissup\Askit\Helper\Config $configHelper,
        \Swissup\Askit\Helper\Url $urlHelper,
        \Swissup\Askit\Model\Vote\Factory $voteFactory,
        \Magento\Framework\View\Element\Template\Context $context
    ) {
        $this->registry = $registry;
        $this->customerSession = $customerSessionFactory->create();
        $this->configHelper = $configHelper;
        $this->urlHelper = $urlHelper;
        $this->voteFactory = $voteFactory;
        $this->originalContext = $context;
    }

    /**
     * @return \Magento\Framework\Registry
     */
    public function getRegistry()
    {
        return $this->registry;
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->customerSession;
    }

    /**
     * @return \Swissup\Askit\Helper\Config
     */
    public function getConfigHelper()
    {
        return $this->configHelper;
    }

    /**
     * @return \Swissup\Askit\Helper\Url
     */
    public function getUrlHelper()
    {
        return $this->urlHelper;
    }

    /**
     * @return \Swissup\Askit\Model\Vote\Factory
     */
    public function getVoteFactory()
    {
        return $this->voteFactory;
    }

    /**
     * @return \Magento\Framework\View\Element\Template\Context
     */
    public function getOriginalContext()
    {
        return $this->originalContext;
    }
}
