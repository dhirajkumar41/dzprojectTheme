<?php

namespace Swissup\Askit\Block\Question\Answer;

use Swissup\Askit\Block\Question;
use Swissup\Askit\Api\Data\MessageInterface;

class View extends Question\AbstractBlock
{
    protected $answer;

    /**
     * @var \Zend_Filter_Interface
     */
    protected $templateProcessor;

    /**
     * @param Question\Context       $context
     * @param \Zend_Filter_Interface $templateProcessor
     * @param array                  $data
     */
    public function __construct(
        Question\Context $context,
        \Zend_Filter_Interface $templateProcessor,
        array $data = []
    ) {
        $this->templateProcessor = $templateProcessor;

        parent::__construct($context, $data);
    }

    /**
     *
     * @param  string $string
     * @return string
     */
    public function filterOutputHtml($string)
    {
        return $this->templateProcessor->filter($string);
    }

    public function setAnswer($answer)
    {
        $this->answer = $answer;
        return $this;
    }

    public function getAnswer()
    {
        return $this->answer;
    }
}
