<?php

namespace Swissup\Askit\Block\Question;

use Magento\Customer\Model\Url;

class AbstractForm extends AbstractBlock
{
    /**
     * @var string
     */
    protected $formId;

    /**
     * @var \Swissup\Askit\Helper\Form
     */
    protected $formHelper;

    /**
     * @var \Magento\Customer\Model\Url
     */
    protected $customerUrl;

    /**
     * @var \Magento\Framework\Url\EncoderInterface
     */
    protected $urlEncoder;

    /**
     * @var \Magento\Captcha\Helper\Data
     */
    protected $captchaHelper;

    /**
     * @var array
     */
    protected $captchaConfig = null;

    /**
     * @param Context                                 $context
     * @param \Swissup\Askit\Helper\Form              $formHelper
     * @param \Magento\Customer\Model\Url             $customerUrl
     * @param \Magento\Framework\Url\EncoderInterface $urlEncoder
     * @param \Magento\Captcha\Helper\Data            $captchaHelper
     * @param array                                   $data
     */
    public function __construct(
        Context $context,
        \Magento\Customer\Model\Url $customerUrl,
        \Magento\Framework\Url\EncoderInterface $urlEncoder,
        \Magento\Captcha\Helper\Data $captchaHelper,
        array $data = []
    ) {
        $this->customerUrl = $customerUrl;
        $this->urlEncoder = $urlEncoder;
        $this->captchaHelper = $captchaHelper;
        parent::__construct($context, $data);
    }

    /**
     * Return login URL
     *
     * @return string
     */
    public function getLoginLink()
    {
        $queryParam = $this->urlEncoder->encode(
            $this->getUrl('*/*/*', ['_current' => true])
        );
        return $this->getUrl(
            'customer/account/login/',
            [Url::REFERER_QUERY_PARAM_NAME => $queryParam]
        );
    }

    /**
     * Return register URL
     *
     * @return string
     */
    public function getRegisterUrl()
    {
        return $this->customerUrl->getRegisterUrl();
    }

    /**
     * Get config for component 'Swissup_Askit/js/view/captcha'.
     *
     * @return array
     */
    public function getCaptchaConfig()
    {
        if ($this->captchaConfig === null) {
            $store = $this->_storeManager->getStore();
            $captcha = $this->captchaHelper->getCaptcha($this->formId);
            if ($captcha->isRequired()) {
                $captcha->generate();
                $this->captchaConfig = [
                    'component' => 'Swissup_Askit/js/view/captcha',
                    'displayArea' => 'additional-form-fields',
                    'formId' => $this->formId,
                    'configSource' => [
                        'isCaseSensitive' => (boolean)$captcha->isCaseSensitive(),
                        'imageHeight' => (int)$captcha->getHeight(),
                        'imageSrc' => $captcha->getImgSrc(),
                        'refreshUrl' => $store->getUrl('captcha/refresh', ['_secure' => $store->isCurrentlySecure()]),
                        'isRequired' => (boolean)$captcha->isRequired()
                    ]
                ];
            } else {
                $this->captchaConfig = [];
            }
        }

        return $this->captchaConfig;
    }
}
