var config = {
    config: {
        mixins: {
            'mage/accordion': {
                'js/mixin/accordion/layered-navigation-expanded': true
            },
            'Magento_Swatches/js/swatch-renderer': {
                'js/mixin/swatch-renderer': true
            }
        }
    }
};
