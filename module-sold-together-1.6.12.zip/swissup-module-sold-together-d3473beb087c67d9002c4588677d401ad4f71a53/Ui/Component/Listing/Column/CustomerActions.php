<?php

namespace Swissup\SoldTogether\Ui\Component\Listing\Column;

class CustomerActions extends OrderActions
{
    /** Url path */
    const URL_PATH_DELETE = 'soldtogether/customer/delete';
}
