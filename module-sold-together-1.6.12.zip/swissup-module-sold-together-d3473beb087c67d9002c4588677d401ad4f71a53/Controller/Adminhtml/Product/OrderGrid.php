<?php
namespace Swissup\SoldTogether\Controller\Adminhtml\Product;

class OrderGrid extends Order
{
}
