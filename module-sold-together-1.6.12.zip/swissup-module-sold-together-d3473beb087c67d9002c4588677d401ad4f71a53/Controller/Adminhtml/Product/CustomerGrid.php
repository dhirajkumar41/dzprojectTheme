<?php
namespace Swissup\SoldTogether\Controller\Adminhtml\Product;

class CustomerGrid extends Customer
{
}
