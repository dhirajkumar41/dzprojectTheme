<?php
namespace Swissup\SoldTogether\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for customer also buy relations search results.
 * @api
 */
interface CustomerSearchResultsInterface extends SearchResultsInterface
{
}
