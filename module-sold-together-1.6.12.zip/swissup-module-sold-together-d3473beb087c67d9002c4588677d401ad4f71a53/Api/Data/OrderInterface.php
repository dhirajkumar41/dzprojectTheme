<?php

namespace Swissup\SoldTogether\Api\Data;

interface OrderInterface extends EntityInterface
{
}
