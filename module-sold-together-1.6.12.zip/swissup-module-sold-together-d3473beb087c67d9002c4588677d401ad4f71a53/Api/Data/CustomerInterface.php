<?php

namespace Swissup\SoldTogether\Api\Data;

interface CustomerInterface extends EntityInterface
{
}
