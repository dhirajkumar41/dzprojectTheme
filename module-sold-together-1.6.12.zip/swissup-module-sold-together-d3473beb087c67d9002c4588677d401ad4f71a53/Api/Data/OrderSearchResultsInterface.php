<?php
namespace Swissup\SoldTogether\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for fruequently bought together relations search results.
 * @api
 */
interface OrderSearchResultsInterface extends SearchResultsInterface
{
}
