<?php
namespace Swissup\SoldTogether\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * SoldTogether customer CRUD interface.
 * @api
 */
interface CustomerRepositoryInterface extends EntityRepositoryInterface
{
}
