<?php
namespace Swissup\SoldTogether\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * SoldTogether order CRUD interface.
 * @api
 */
interface OrderRepositoryInterface extends EntityRepositoryInterface
{
}
