var config = {
    map: {
        '*': {
            soldIndexing : 'Swissup_SoldTogether/js/sold-indexing'
        }
    }
};
