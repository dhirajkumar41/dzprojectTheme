<?php
namespace Swissup\HoverGallery\Observer;

use Magento\Framework\Data\Collection;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Catalog\Model\Product\Gallery\ReadHandler;
use Magento\Catalog\Model\ResourceModel\Product\Gallery;
use Magento\Store\Model\StoreManagerInterface;

class AppendMediaGalleryBeforeHtml implements ObserverInterface
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var Gallery
     */
    private $gallery;

    /**
     * @var ReadHandler
     */
    private $readHandler;

    /**
     * @param StoreManagerInterface $storeManager
     * @param Gallery               $gallery
     * @param ReadHandler           $readHandler
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        Gallery $gallery,
        ReadHandler $readHandler
    ) {
        $this->storeManager = $storeManager;
        $this->gallery = $gallery;
        $this->readHandler = $readHandler;
    }

    /**
     * Append media gallery before rendering html
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return \Swissup\HoverGallery\Observer
     */
    public function execute(Observer $observer)
    {
        $productCollection = $observer->getEvent()->getCollection();
        if ($productCollection instanceof Collection
            && $productCollection->getFlag(SetFlagPreloadHoverImage::FLAG_NAME)
        ) {
            $productIds = $productCollection->getColumnValues('entity_id');
            if (!$productIds) {
                return $this;
            }

            $select = $this->gallery->createBatchBaseSelect(
                $this->storeManager->getStore()->getId(),
                $this->readHandler->getAttribute()->getAttributeId()
            );
            $select->where('entity.entity_id in (?)', $productIds);
            $galleryData = $this->gallery->getConnection()->fetchAll($select);

            foreach ($productCollection as $product) {
                $media = [];
                foreach ($galleryData as $item) {
                    if ($product->getId() == $item['entity_id']) {
                        $media[] = $item;
                    }
                }
                $this->readHandler->addMediaDataToProduct($product, $media);
                $images = $this->getActiveMediaGalleryEntries($product);

                if ($images
                    && isset($images[1])
                    && $images[1]->getFile() != $product->getImage()
                ) {
                    $product->setHoverImage($images[1]);
                }
            }

            // unset flag
            $productCollection->getFlag(SetFlagPreloadHoverImage::FLAG_NAME, null);
        }

        return $this;
    }

    /**
     * @param  \Magento\Catalog\Model\Product $product
     * @return array
     */
    private function getActiveMediaGalleryEntries($product)
    {
        $images = $product->getMediaGalleryEntries();
        $result = [];

        foreach ($images as $image) {
            if ($image->isDisabled()) {
                continue;
            }
            $result[] = $image;
        }

        return $result;
    }
}
