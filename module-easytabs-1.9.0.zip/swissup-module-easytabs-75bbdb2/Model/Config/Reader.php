<?php
namespace Swissup\Easytabs\Model\Config;

class Reader extends \Magento\Widget\Model\Config\Reader
{

}
