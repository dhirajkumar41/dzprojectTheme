var config = {
    config: {
        mixins: {
            'mage/collapsible': {
                'Swissup_Easytabs/js/mixin/collapsible': true
            }
        }
    }
};
