<?php

namespace Swissup\Easytabs\Block\Adminhtml;

use Magento\Framework\View\Element\Template;

class WidgetOptions extends Template
{
    protected $_template = 'Swissup_Easytabs::widget-options.phtml';
}
