<?php

namespace Swissup\Marketplace\Model;

class Package extends \Magento\Framework\DataObject
{
    //
}
