var config = {
    map: {
        '*': {
            reminderIndexing : 'Swissup_Reviewreminder/js/reminder-indexing',
            reminderEmailPreview : 'Swissup_Reviewreminder/js/reminder-email-preview'
        }
    }
};
