var config = {
    map: {
        '*': {
            'swissupTestimonialsList' : 'Swissup_Testimonials/js/Swissup/testimonials/testimonials-list'
        }
    }
};
