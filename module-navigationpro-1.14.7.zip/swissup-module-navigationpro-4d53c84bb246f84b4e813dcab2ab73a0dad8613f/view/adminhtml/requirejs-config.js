var config = {
    config: {
        mixins: {
            'Magento_Ui/js/lib/validation/rules': {
                'Swissup_Navigationpro/js/validation/navpro-validate-unique': true
            }
        }
    }
};
