define([
    'Magento_Ui/js/form/element/wysiwyg',
    'Magento_Catalog/js/components/visible-on-option/strategy'
], function (Element, strategy) {
    'use strict';

    return Element.extend(strategy);
});
