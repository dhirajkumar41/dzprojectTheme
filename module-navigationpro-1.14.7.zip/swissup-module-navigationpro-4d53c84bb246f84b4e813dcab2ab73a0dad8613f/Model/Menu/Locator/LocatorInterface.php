<?php

namespace Swissup\Navigationpro\Model\Menu\Locator;

interface LocatorInterface
{
    /**
     * @return \Swissup\Navigationpro\Model\Menu
     */
    public function getMenu();
}
