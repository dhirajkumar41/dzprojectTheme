<?php

namespace Swissup\Navigationpro\Model\Item\Locator;

interface LocatorInterface
{
    /**
     * @return \Swissup\Navigationpro\Model\Item
     */
    public function getItem();
}
