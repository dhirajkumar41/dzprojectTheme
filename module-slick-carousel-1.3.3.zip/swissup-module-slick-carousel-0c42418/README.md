# Slick Carousel

[the last carousel you'll ever need][slick_homepage] for Magento2

### Installation

```bash
cd <magento_root>
composer require swissup/module-slick-carousel
bin/magento module:enable Swissup_SlickCarousel
bin/magento setup:upgrade
```

### Docs

See the docs at [swissuplabs site](http://docs.swissuplabs.com/m2/extensions/slick-carousel/).

[slick_homepage]: https://github.com/kenwheeler/slick
