var config = {
    map: {
        '*': {
            'slick': 'Swissup_SlickCarousel/js/slick',
            'slickwrapper': 'Swissup_SlickCarousel/js/slickwrapper'
        }
    }
};
