define([
    'jquery',
    'Swissup_Gdpr/js/model/cookie-manager'
], function ($, cookieManager) {
    'use strict';

    var element;

    return function (settings, el) {
        if (cookieManager.isCookieExists()) {
            return;
        }

        element = $(el).removeClass('hidden').addClass('shown');

        $(document.body).on('click', '.accept-cookie-consent', function () {
            $('#btn-cookie-allow').click(); // built-in cookie restriction notice
            element.removeClass('shown');
        });
    };
});
