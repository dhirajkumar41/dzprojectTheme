define([
    'jquery',
    'ko',
    'uiComponent',
    'mage/translate',
    'Swissup_Gdpr/js/model/cookie-manager',
    'mage/cookies'
], function ($, ko, Component, $t, cookieManager) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Swissup_Gdpr/cookie-settings'
        },
        timers: {},
        messages: {},

        /**
         * @param {Object} group
         * @param {Object} event
         */
        keypress: function (group, event) {
            if (event.keyCode !== 32) { // space
                return;
            }
            this.toggleGroup(group);
        },

        enableAll: function () {
            _.each(this.groups, function (group) {
                if (cookieManager.group(group.code).status()) {
                    return;
                }
                this.toggleGroup(group);
            }.bind(this));
        },

        /**
         * @param {Object} group
         */
        toggleGroup: function (group) {
            var code = group.code,
                group = cookieManager.group(code),
                status = !group.status();

            if (group.required()) {
                return this.showMessage(code, $t('This group is required.'));
            }

            group.status(status);

            if (cookieManager.isCookieExists()) {
                setTimeout(function () {
                    this.showMessage(code, $t('Saved'));
                }.bind(this), 100);
            }
        },

        showMessage: function (groupCode, message) {
            if (this.timers[groupCode]) {
                clearTimeout(this.timers[groupCode]);
                this.timers[groupCode] = false;
            }

            this.messages[groupCode](message);

            if (message.length) {
                this.timers[groupCode] = setTimeout(function () {
                    this.messages[groupCode]('');
                }.bind(this), 1500);
            }
        },

        /**
         * @param {Object} group
         * @return {Boolean}
         */
        isGroupEnabled: function (group) {
            return cookieManager.group(group.code).status();
        },

        /**
         * @param {Object} group
         * @return {String}
         */
        getMessage: function (group) {
            if (!this.messages[group.code]) {
                this.messages[group.code] = ko.observable('');
            }
            return this.messages[group.code]();
        },

        /**
         * @param {Object} component
         * @param {Object} event
         */
        acceptConsent: function (component, event) {
            $('#btn-cookie-allow').click(); // built-in cookie restriction notice

            $(event.target)
                .outerWidth($(event.target).outerWidth())
                .addClass('gdpr-loading')
                .text($t('Saving..'));

            cookieManager.updateCookie(function () {
                $(event.target)
                    .removeClass('gdpr-loading')
                    .text($t('Saved'));
            });
        },

        discardConsent: function () {
            cookieManager.removeCookie();
            window.location.reload();
        },

        /**
         * @return {Boolean}
         */
        isAcceptButtonVisible: function () {
            return !$.mage.cookies.get(this.cookieName);
        }
    });
});
