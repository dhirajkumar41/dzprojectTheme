define([
    'jquery'
], function ($) {
    'use strict';

    return function (name) {
        return $.ajax({
            url: window.swissupGdprCookieSettings.registerUrl,
            method: 'post',
            dataType: 'json',
            data: {
                form_key: $.mage.cookies.get('form_key'),
                name: name,
                location: window.location.href
            }
        }).done(function (data) {
            if (data.error) {
                return console.error(data.message);
            }
        });
    };
});
