define([
    'Magento_Ui/js/lib/view/utils/async',
    'ko',
    'underscore',
    'Swissup_Gdpr/js/action/accept-cookie-groups',
    'Swissup_Gdpr/js/action/register-unknown-cookie',
    'mage/cookies',
    'jquery/jquery-storageapi'
], function ($, ko, _, acceptCookieGroups, registerUnknownCookie) {
    'use strict';

    var isCookieExists = ko.observable(),
        settings = window.swissupGdprCookieSettings || {},
        dummyGroup = {
            code: '!notfound',
            required: false
        },
        updateCookie,
        cookies = {},
        groups = {};

    /**
     * @param {String} code
     * @return {Object}
     */
    function getGroupSettings(code) {
        if (!settings.groups[code]) {
            return dummyGroup;
        }
        return settings.groups[code];
    }

    /**
     * Return setting from settings.cookies object.
     * If not found, try to use search algorithm:
     *
     *  dc_gtm_someid will return setting of dc_gtm_* key.
     *
     * @param {String} name
     * @return {String|Boolean}
     */
    function getCookieSettings(name) {
        var patterns;

        if (settings.cookies[name]) {
            return settings.cookies[name];
        }

        // find declared patterns
        patterns = _.filter(_.keys(settings.cookies), function (key) {
            return key.indexOf('*') > 0;
        });

        // remove * from the patterns
        patterns = _.map(patterns, function (pattern) {
            return pattern.replace('*', '');
        });

        // move longest patterns to the top
        patterns.sort(function (a, b) {
            return b.length - a.length;
        });

        // find pattern to use
        name = _.find(patterns, function (prefix) {
            return name.indexOf(prefix) === 0 && name.length > prefix.length;
        });

        if (name) {
            return settings.cookies[name + '*'];
        }

        return false;
    }

    /**
     * @param {String} name
     * @return {Object}
     */
    function getGroupSettingsByCookieName(name) {
        var cookie = getCookieSettings(name);

        if (!cookie || !settings.groups[cookie.group]) {
            console.log('Unknown Cookie: ' + name);

            registerUnknownCookie(name);

            return dummyGroup;
        }

        return settings.groups[cookie.group];
    }

    /**
     * @param {String} code
     * @param {Boolean} status
     */
    function initGroup(code, status) {
        var group = getGroupSettings(code);

        groups[code] = {
            code: code,
            status: ko.observable(status || group.required),
            required: group.required
        }
    }

    /**
     * @param {String} name
     * @return {Object}
     */
    function getGroupByCookieName(name) {
        var settings = getGroupSettingsByCookieName(name);

        if (!groups[settings.code]) {
            initGroup(settings.code);
        }

        return groups[settings.code];
    }

    /**
     * @return {Array}
     */
    function getAllowedGroupNames() {
        return _.pluck(_.filter(groups, function (group) {
            return group.status();
        }), 'code');
    }

    /**
     * @param {String} groupCode
     */
    function removeCookies(groupCode) {
        var cookies = _.filter(settings.cookies, function (el) {
            return el.group === groupCode && $.mage.cookies.get(el.name);
        });

        _.map(cookies, function (cookie) {
            // some modules use this
            $.mage.cookies.clear(cookie.name);

            // other use this (different domain here)
            if (window.cookieStorage && window.cookieStorage.setItem) {
                window.cookieStorage.setItem(cookie.name, '', {
                    expires: new Date('Jan 01 1970 00:00:01 GMT')
                });
            }
        });
    }

    /**
     * Remove module's cookie
     */
    function removeCookie() {
        $.mage.cookies.clear(settings.cookieName);
    }

    /**
     * Update cookie value
     */
    function updateCookieNow(callback) {
        var date = new Date(),
            expires = new Date(date),
            groups = getAllowedGroupNames();

        expires.setDate(expires.getDate() + settings.lifetime);

        $.mage.cookies.set(
            settings.cookieName,
            JSON.stringify({
                groups: groups,
                date: date.getTime()
            }),
            {
                expires: expires
            }
        );

        isCookieExists(true);

        acceptCookieGroups(groups).done(callback);
    }

    updateCookie = _.debounce(updateCookieNow, 200);

    /**
     * Read cookie
     */
    (function readCookie() {
        var consent = $.mage.cookies.get(settings.cookieName);

        if (!consent || !consent.length) {
            return;
        }

        try {
            consent = JSON.parse(consent);
        } catch (e) {
            return;
        }

        isCookieExists(true);

        _.each(consent.groups, function (name) {
            initGroup(name, true);
        });
    })();

    /**
     * Init all declared groups
     */
    (function initGroups() {
         _.each(settings.groups, function (group) {
            if (!groups[group.code]) {
                initGroup(group.code);
            }
        });
    })();

    function allowAllGroups() {
        _.map(groups, function (group) {
            return group.status(true);
        });

        updateCookie();
    }

    $.async('[data-cookies-allow-all]', function (el) {
        $(el).click(allowAllGroups);
    });
    $.async('[data-cookies-accept]', function (el) {
        $(el).click(updateCookie);
    });

    return {
        /**
         * @return {Boolean}
         */
        isCookieExists: isCookieExists,

        /**
         * Update cookie value
         */
        updateCookie: updateCookie,

        /**
         * Remove cookie
         */
        removeCookie: removeCookie,

        /**
         * @param {String} name
         * @return {Object}
         */
        group: function (name) {
            if (!groups[name]) {
                initGroup(name);
            }

            return {
                /**
                 * @param {Boolean} flag
                 * @return {Mixed}
                 */
                status: function (flag) {
                    if (flag !== undefined) {
                        if (!flag) {
                            removeCookies(name);
                        }

                        groups[name].status(flag);

                        if (!isCookieExists()) {
                            return; // client must press 'Accept' button to save cookie
                        }

                        return updateCookie();
                    }

                    return groups[name].status();
                },

                /**
                 * @return {Boolean}
                 */
                required: function () {
                    return groups[name].required;
                }
            }
        },

        /**
         * @param {String} name
         * @return {Object}
         */
        cookie: function (name) {
            if (!cookies[name]) {
                cookies[name] = {
                    name: name,
                    status: function () {
                        return getGroupByCookieName(name).status();
                    }
                }
            }

            return {
                /**
                 * @return {Boolean}
                 */
                status: function () {
                    return cookies[name].status();
                }
            }
        }
    }
});
