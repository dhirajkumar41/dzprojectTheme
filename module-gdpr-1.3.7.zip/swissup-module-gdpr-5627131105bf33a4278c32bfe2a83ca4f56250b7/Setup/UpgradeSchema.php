<?php

namespace Swissup\Gdpr\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrade DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.1.0', '<')) {
            $this->createClientConsentTable($setup);
        }

        if (version_compare($context->getVersion(), '1.2.0', '<')) {
            $this->createClientRequestTable($setup);
        }

        if (version_compare($context->getVersion(), '1.2.1', '<')) {
            $this->addReportColumnToClientRequestTable($setup);
        }

        if (version_compare($context->getVersion(), '1.2.2', '<')) {
            $this->addWebsiteIdColumnsToConsentAndRequestTables($setup);
        }

        if (version_compare($context->getVersion(), '1.2.3', '<')) {
            $this->addIndexesToConsentAndRequestTables($setup);
        }

        if (version_compare($context->getVersion(), '1.3.0', '<')) {
            $this->createCookieTable($setup);
        }

        if (version_compare($context->getVersion(), '1.3.1', '<')) {
            $this->createCookieGroupTable($setup);
        }

        if (version_compare($context->getVersion(), '1.3.2', '<')) {
            $this->createBlockedCookieTable($setup);
        }

        if (version_compare($context->getVersion(), '1.3.3', '<')) {
            $this->modifyConsentUpdatedAtColumn($setup);
        }

        $setup->endSetup();
    }

    private function createBlockedCookieTable($setup)
    {
        $table = $setup->getConnection()->newTable(
                $setup->getTable('swissup_gdpr_blocked_cookie')
            )
            ->addColumn(
                'cookie_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity'  => true,
                    'unsigned'  => true,
                    'nullable'  => false,
                    'primary'   => true,
                ],
                'ID'
            )
            ->addColumn(
                'name',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Name'
            )
            ->addColumn(
                'description',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false],
                'Description'
            )
            ->setComment('Blocked Cookies');

        $setup->getConnection()->createTable($table);
    }

    private function createCookieGroupTable($setup)
    {
        /**
         * Create table 'swissup_gdpr_cookie'
         */
        $table = $setup->getConnection()->newTable(
                $setup->getTable('swissup_gdpr_cookie_group')
            )
            ->addColumn(
                'group_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity'  => true,
                    'unsigned'  => true,
                    'nullable'  => false,
                    'primary'   => true,
                ],
                'ID'
            )
            ->addColumn(
                'code',
                Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                'Code'
            )
            ->addColumn(
                'sort_order',
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned'  => true,
                    'nullable'  => false,
                    'default' => '100',
                ],
                'Sort Order'
            )
            ->addColumn(
                'required',
                Table::TYPE_SMALLINT,
                null,
                ['nullable' => false, 'default' => 0],
                'Is Required'
            )
            ->setComment('Custom Cookie Groups');

        $setup->getConnection()->createTable($table);

        /**
         * Create table 'swissup_gdpr_cookie_group_content'
         */
        $table = $setup->getConnection()->newTable(
                $setup->getTable('swissup_gdpr_cookie_group_content')
            )
            ->addColumn(
                'group_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned'  => true,
                    'nullable'  => false,
                ],
                'ID'
            )
            ->addColumn(
                'store_id',
                Table::TYPE_SMALLINT,
                null,
                [
                    'nullable' => false,
                    'unsigned' => true,
                    'default' => '0'
                ],
                'Store ID'
            )
            ->addColumn(
                'title',
                Table::TYPE_TEXT,
                null,
                ['nullable' => true],
                'Title'
            )
            ->addColumn(
                'description',
                Table::TYPE_TEXT,
                null,
                ['nullable' => true],
                'Description'
            )
            ->addIndex(
                $setup->getIdxName('swissup_gdpr_cookie_group_content', ['group_id', 'store_id']),
                ['group_id', 'store_id'],
                [
                    'type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_PRIMARY
                ]
            )
            ->addIndex(
                $setup->getIdxName('swissup_gdpr_cookie_group_content', ['store_id']),
                ['store_id']
            )
            ->addForeignKey(
                $setup->getFkName(
                    'swissup_gdpr_cookie_group_content',
                    'group_id',
                    'swissup_gdpr_cookie_group',
                    'group_id'
                ),
                'group_id',
                $setup->getTable('swissup_gdpr_cookie_group'),
                'group_id',
                Table::ACTION_CASCADE
            )
            ->addForeignKey(
                $setup->getFkName(
                    'swissup_gdpr_cookie_group_content',
                    'store_id',
                    'store',
                    'store_id'
                ),
                'store_id',
                $setup->getTable('store'),
                'store_id',
                Table::ACTION_CASCADE
            )
            ->setComment('Custom Cookie Groups Content');

        $setup->getConnection()->createTable($table);
    }

    private function createCookieTable($setup)
    {
        /**
         * Create table 'swissup_gdpr_cookie'
         */
        $table = $setup->getConnection()->newTable(
                $setup->getTable('swissup_gdpr_cookie')
            )
            ->addColumn(
                'cookie_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity'  => true,
                    'unsigned'  => true,
                    'nullable'  => false,
                    'primary'   => true,
                ],
                'ID'
            )
            ->addColumn(
                'name',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Name'
            )
            ->addColumn(
                'group',
                Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                'Group Code'
            )
            ->addColumn(
                'status',
                Table::TYPE_SMALLINT,
                null,
                ['nullable' => false, 'default' => 0],
                'Status'
            )
            ->setComment('Custom Cookies');

        $setup->getConnection()->createTable($table);

        /**
         * Create table 'swissup_gdpr_cookie_content'
         */
        $table = $setup->getConnection()->newTable(
                $setup->getTable('swissup_gdpr_cookie_content')
            )
            ->addColumn(
                'cookie_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned'  => true,
                    'nullable'  => false,
                ],
                'ID'
            )
            ->addColumn(
                'store_id',
                Table::TYPE_SMALLINT,
                null,
                [
                    'nullable' => false,
                    'unsigned' => true,
                    'default' => '0'
                ],
                'Store ID'
            )
            ->addColumn(
                'description',
                Table::TYPE_TEXT,
                null,
                ['nullable' => true],
                'Description'
            )
            ->addIndex(
                $setup->getIdxName('swissup_gdpr_cookie_content', ['cookie_id', 'store_id']),
                ['cookie_id', 'store_id'],
                [
                    'type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_PRIMARY
                ]
            )
            ->addIndex(
                $setup->getIdxName('swissup_gdpr_cookie_content', ['store_id']),
                ['store_id']
            )
            ->addForeignKey(
                $setup->getFkName(
                    'swissup_gdpr_cookie_content',
                    'cookie_id',
                    'swissup_gdpr_cookie',
                    'cookie_id'
                ),
                'cookie_id',
                $setup->getTable('swissup_gdpr_cookie'),
                'cookie_id',
                Table::ACTION_CASCADE
            )
            ->addForeignKey(
                $setup->getFkName(
                    'swissup_gdpr_cookie_content',
                    'store_id',
                    'store',
                    'store_id'
                ),
                'store_id',
                $setup->getTable('store'),
                'store_id',
                Table::ACTION_CASCADE
            )
            ->setComment('Custom Cookies Content');

        $setup->getConnection()->createTable($table);
    }

    private function addIndexesToConsentAndRequestTables($setup)
    {
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_consent'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_consent'),
                ['website_id']
            ),
            ['website_id']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_consent'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_consent'),
                ['client_identity_field']
            ),
            ['client_identity_field']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_consent'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_consent'),
                ['client_identity']
            ),
            ['client_identity']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_consent'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_consent'),
                ['visitor_id']
            ),
            ['visitor_id']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_consent'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_consent'),
                ['updated_at']
            ),
            ['updated_at']
        );

        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['website_id']
            ),
            ['website_id']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['client_identity_field']
            ),
            ['client_identity_field']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['client_identity']
            ),
            ['client_identity']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['type']
            ),
            ['type']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['confirmation_token']
            ),
            ['confirmation_token']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['created_at']
            ),
            ['created_at']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['executed_at']
            ),
            ['executed_at']
        );
        $setup->getConnection()->addIndex(
            $setup->getTable('swissup_gdpr_client_request'),
            $setup->getIdxName(
                $setup->getTable('swissup_gdpr_client_request'),
                ['status']
            ),
            ['status']
        );
    }

    private function addWebsiteIdColumnsToConsentAndRequestTables($setup)
    {
        $setup->getConnection()->addColumn(
            $setup->getTable('swissup_gdpr_client_consent'),
            'website_id',
            [
                'type' => Table::TYPE_SMALLINT,
                'unsigned' => true,
                'default' => 0,
                'comment' => 'Website ID',
                'after' => 'entity_id'
            ]
        );

        $setup->getConnection()->addColumn(
            $setup->getTable('swissup_gdpr_client_request'),
            'website_id',
            [
                'type' => Table::TYPE_SMALLINT,
                'unsigned' => true,
                'default' => 0,
                'comment' => 'Website ID',
                'after' => 'entity_id'
            ]
        );
    }

    private function addReportColumnToClientRequestTable($setup)
    {
        $setup->getConnection()->addColumn(
            $setup->getTable('swissup_gdpr_client_request'),
            'report',
            [
                'type' => Table::TYPE_TEXT,
                'nullable' => true,
                'comment' => 'Report Messages'
            ]
        );
    }

    private function createClientRequestTable($setup)
    {
        $connection = $setup->getConnection();

        /**
         * Create table 'swissup_gdpr_client_request'
         */
        $table = $connection->newTable(
                $setup->getTable('swissup_gdpr_client_request')
            )
            ->addColumn(
                'entity_id',
                Table::TYPE_BIGINT,
                null,
                [
                    'identity'  => true,
                    'unsigned'  => true,
                    'nullable'  => false,
                    'primary'   => true,
                ],
                'Entity ID'
            )
            ->addColumn(
                'client_identity_field',
                Table::TYPE_TEXT,
                32,
                ['nullable' => false],
                'Client\'s Identity Field'
            )
            ->addColumn(
                'client_identity',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Client\'s Identity Value'
            )
            ->addColumn(
                'customer_id',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => true, 'unsigned' => true],
                'Customer ID'
            )
            ->addColumn(
                'type',
                Table::TYPE_SMALLINT,
                null,
                ['nullable' => false],
                'Request Type'
            )
            ->addColumn(
                'confirmation_token',
                Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                'Confirmation Token'
            )
            ->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                'Created At'
            )
            ->addColumn(
                'confirmed_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => true, 'default' => null],
                'Confirmed At'
            )
            ->addColumn(
                'executed_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => true, 'default' => null],
                'Executed At'
            )
            ->addColumn(
                'status',
                Table::TYPE_SMALLINT,
                null,
                ['nullable' => false, 'default' => 0],
                'Status'
            )
            ->addForeignKey(
                $setup->getFkName(
                    'swissup_gdpr_client_request',
                    'customer_id',
                    'customer_entity',
                    'entity_id'
                ),
                'customer_id',
                $setup->getTable('customer_entity'),
                'entity_id',
                Table::ACTION_SET_NULL
            )
            ->setComment(
                'List of client requests'
            );

        $connection->createTable($table);
    }

    private function createClientConsentTable($setup)
    {
        $connection = $setup->getConnection();

        /**
         * Create table 'swissup_gdpr_client_consent'
         */
        $table = $connection->newTable(
                $setup->getTable('swissup_gdpr_client_consent')
            )
            ->addColumn(
                'entity_id',
                Table::TYPE_BIGINT,
                null,
                [
                    'identity'  => true,
                    'unsigned'  => true,
                    'nullable'  => false,
                    'primary'   => true,
                ],
                'Entity ID'
            )
            ->addColumn(
                'client_identity_field',
                Table::TYPE_TEXT,
                32,
                ['nullable' => false],
                'Client\'s Identity Field'
            )
            ->addColumn(
                'client_identity',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Client\'s Identity Value'
            )
            ->addColumn(
                'visitor_id',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false, 'unsigned' => true, 'default' => '0'],
                'Visitor ID'
            )
            ->addColumn(
                'customer_id',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => true, 'unsigned' => true],
                'Customer ID'
            )
            ->addColumn(
                'form_id',
                Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                'Form ID'
            )
            ->addColumn(
                'consent_id',
                Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                'Consent ID'
            )
            ->addColumn(
                'consent_title',
                Table::TYPE_TEXT,
                512,
                ['nullable' => false],
                'Consent title'
            )
            ->addColumn(
                'updated_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                'Update Time'
            )
            ->addForeignKey(
                $setup->getFkName(
                    'swissup_gdpr_client_consent',
                    'customer_id',
                    'customer_entity',
                    'entity_id'
                ),
                'customer_id',
                $setup->getTable('customer_entity'),
                'entity_id',
                Table::ACTION_CASCADE
            )
            ->setComment(
                'List of approved consents'
            );

        $connection->createTable($table);
    }

    private function modifyConsentUpdatedAtColumn($setup)
    {
        $setup->getConnection()->modifyColumn(
            $setup->getTable('swissup_gdpr_client_consent'),
            'updated_at',
            [
                'type' => Table::TYPE_TIMESTAMP,
                'nullable' => false,
                'default' => Table::TIMESTAMP_INIT_UPDATE,
            ]
        );
    }
}
