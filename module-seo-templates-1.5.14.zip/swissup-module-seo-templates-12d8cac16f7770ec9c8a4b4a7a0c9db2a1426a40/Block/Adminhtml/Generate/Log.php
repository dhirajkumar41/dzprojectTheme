<?php

namespace Swissup\SeoTemplates\Block\Adminhtml\Generate;

class Log extends \Magento\Framework\View\Element\Template
{
    /**
     * {@inheritdoc}
     */
    protected $_template = 'generate/log.phtml';
}
