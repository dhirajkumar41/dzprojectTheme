<?php

namespace Swissup\SeoTemplates\Model;

use Magento\Store\Model\StoreManagerInterface;

class SeodataBuilder
{
    /**
     * @var ResourceModel\Seodata
     */
    protected $resourceModel;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var array
     */
    private $cache = [];

    /**
     * @param SeodataFactory        $factory
     * @param ResourceModel\Seodata $resourceModel
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        SeodataFactory $factory,
        ResourceModel\Seodata $resourceModel,
        StoreManagerInterface $storeManager
    ) {
        $this->factory = $factory;
        $this->resourceModel = $resourceModel;
        $this->storeManager = $storeManager;
    }

    /**
     * Get DataObject with metadata (with memoization).
     *
     * @param  int    $entityId
     * @param  string $entityType
     * @return \Magento\Framework\DataObject
     */
    public function get($entityId, $entityType)
    {
        $collected = $this->_get([$entityId], $entityType);

        return reset($collected);
    }

    /**
     * Private getter for generated metadata.
     *
     * @param  array  $entityIds
     * @param  int    $entityType
     * @return array
     */
    private function _get(array $entityIds, $entityType)
    {
        if (array_diff($entityIds, array_keys($this->cache[$entityType] ?? []))) {
            $rawData = $this->resourceModel->getRawGenerated(
                $entityIds,
                $entityType,
                $this->storeManager->getStore()->getId()
            );
            $this->cache[$entityType] = [];
            foreach ($entityIds as $entityId) {
                $this->cache[$entityType][$entityId] = new \Magento\Framework\DataObject;
                foreach ($rawData as $data) {
                    if ($entityId !== $data['entity_id']) {
                        continue;
                    }

                    $item = $this->factory->create(['data' => $data]);
                    $this->resourceModel->unserializeFields($item);
                    $this->cache[$entityType][$entityId]->addData($item->getMetadata());

                }
            }
        }

        return $entityIds
            ? array_intersect_key($this->cache[$entityType], array_flip($entityIds))
            : [];
    }

    /**
     * Preload (warm up) generated metadata.
     *
     * @param  array  $entityIds
     * @param  int    $entityType
     * @return $this
     */
    public function preload(array $entityIds, $entityType)
    {
        $this->_get($entityIds, $entityType);

        return $this;
    }
}
