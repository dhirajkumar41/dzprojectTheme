<?php

namespace Swissup\ProLabels\Helper;

use Swissup\ProLabels\Helper\AbstractLabel;
use Magento\Store\Model\ScopeInterface;
use Magento\Catalog\Api\Data\ProductInterface;

/**
 * System Labels - on sale, new, in stock, out stock
 */
class ProductLabels extends AbstractLabel
{
    /**
     * @return Get On Sale Label Data
     */
    public function getOnSaleLabel($product, $mode)
    {
        $isOnSaleConfig = $this->scopeConfig->getValue("prolabels/on_sale/{$mode}", ScopeInterface::SCOPE_STORE);
        if (!$isOnSaleConfig["active"]
            || !$this->isOnSale($product)
        ) {
            return false;
        }

        return $this->getLabelOutputObject($isOnSaleConfig);
    }

    /**
     * @return Get Is New Label Data
     */
    public function getIsNewLabel($product, $mode)
    {
        $isInSaleConfig = $this->scopeConfig->getValue("prolabels/is_new/{$mode}", ScopeInterface::SCOPE_STORE);
        if (!$isInSaleConfig["active"]
            || !$this->isNew($product)
        ) {
            return false;
        }

        return $this->getLabelOutputObject($isInSaleConfig);
    }

    /**
     * @return Get Stock Label Data
     */
    public function getStockLabel($product, $mode)
    {
        $stockConfig = $this->scopeConfig->getValue("prolabels/in_stock/{$mode}", ScopeInterface::SCOPE_STORE);
        if (!$stockConfig["active"]
            || !$this->isAvailable($product)
        ) {
            return false;
        }

        $qty = $this->getStockQty($product);
        if ($qty <= 0
            || $qty >= $stockConfig['stock_lower']
        ) {
            return false;
        }

        return $this->getLabelOutputObject($stockConfig);
    }

    /**
     * @return Get Out Of Stock Label Data
     */
    public function getOutOfStockLabel($product, $mode)
    {
        $stockConfig = $this->scopeConfig->getValue("prolabels/out_stock/{$mode}", ScopeInterface::SCOPE_STORE);
        if (!$stockConfig["active"]
            || $this->isAvailable($product)
        ) {
            return false;
        }

        return $this->getLabelOutputObject($stockConfig);
    }

    /**
     * Check If Product Has Discount
     *
     * @param $product \Magento\Catalog\Model\Product
     * @return
     */
    public function isOnSale($product)
    {
        if ('bundle' === $product->getTypeId()) {
            if ((int)$product->getSpecialPrice()) {
                $specialPriceFrom = $product->getSpecialFromDate();
                $specialPriceTo = $product->getSpecialToDate();
                $store = $this->storeManager->getStore()->getId();
                return $this->localeDate->isScopeDateInInterval(
                    $store,
                    $specialPriceFrom,
                    $specialPriceTo
                );
            }
        } elseif ('grouped' === $product->getTypeId()) {
            /** @var \Magento\Catalog\Model\ResourceModel\Product\Collection $simpleProductIds */
            $simpleProductIds = $product->getTypeInstance()->getAssociatedProducts($product);
            foreach($simpleProductIds as $simpleProduct) {
                if ($this->getFinalPrice($simpleProduct) < $this->getRegularPrice($simpleProduct)) {
                    return true;
                }
            }
        } else {
            $finalPrice = $this->getFinalPrice($product);
            $regularPrice = $this->getRegularPrice($product);
            return $finalPrice < $regularPrice;
        }

        return false;
    }

    /**
     * Improved method to get regular price of product
     *
     * @param  ProductInterface $product
     * @return float
     */
    public function getRegularPrice(ProductInterface $product)
    {
        return $this->price->getRegularPrice($product);
    }

    /**
     * Get final price of product
     *
     * @param  ProductInterface $product
     * @return float
     */
    public function getFinalPrice(ProductInterface $product)
    {
        return $this->price->getFinalPrice($product);
    }

    /**
     * Get special price of product
     *
     * @param  ProductInterface $product
     * @return float
     */
    public function getSpecialPrice(ProductInterface $product)
    {
        return $this->price->getSpecialPrice($product);
    }
}
