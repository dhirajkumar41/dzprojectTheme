<?php

namespace Swissup\ProLabels\Model;

use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockItemCriteriaInterfaceFactory;
use Magento\CatalogInventory\Api\StockItemRepositoryInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\Session;

class Stock
{
    /**
     * @var array
     */

    private $cachedQty = [];
    /**
     * @var StockConfigurationInterface
     */
    protected $stockConfiguration;

    /**
     * @var StockItemCriteriaInterfaceFactory
     */
    protected $criteriaFactory;

    /**
     * @var StockItemRepositoryInterface
     */
    protected $stockItemRepository;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var Session
     */
    protected $session;


    public function __construct(
        StockConfigurationInterface $stockConfiguration,
        StockItemCriteriaInterfaceFactory $criteriaFactory,
        StockItemRepositoryInterface $stockItemRepository,
        StoreManagerInterface $storeManager,
        Session $session
    ) {
        $this->stockConfiguration = $stockConfiguration;
        $this->criteriaFactory = $criteriaFactory;
        $this->stockItemRepository = $stockItemRepository;
        $this->storeManager = $storeManager;
        $this->session = $session;
    }

    /**
     * Get stock quantoty for product
     *
     * @param  ProductInterface $product
     * @return
     */
    public function getQty(ProductInterface $product)
    {
        $ids = $this->getChildIds($product);
        if (!$ids) {
            $ids = [$product->getId()];
        }

        $qtys = $this->_getStockQty($ids);

        return $qtys ? min(array_values($qtys)) : 0;
    }

    /**
     * Get ids of child products
     *
     * @param  ProductInterface $product
     * @return array
     */
    public function getChildIds(ProductInterface $product)
    {
        $ids = [];
        if ('grouped' === $product->getTypeId()) {
            $ids = $product->getTypeInstance()->getAssociatedProductIds($product);
        } elseif ('bundle' === $product->getTypeId()) {
            $optionIds = $product->getTypeInstance()->getOptionsIds($product);
            /** @var \Magento\Catalog\Model\ResourceModel\Product\Collection $simpleProducts */
            $simpleProducts = $product->getTypeInstance()->getSelectionsCollection($optionIds, $product);
            $ids = $simpleProducts->getAllIds();
        } elseif ('configurable' === $product->getTypeId()) {
            $simpleProducts = $product->getTypeInstance()->getUsedProducts($product);
            $ids = [];
            foreach ($simpleProducts as $simpleProduct) {
                $ids[] = $simpleProduct->getId();
            }
        }

        return $ids;
    }

    /**
     * Preload (warm) stock data for collection (array) of products
     *
     * @param  ProductInterface[]  $products
     * @return $this
     */
    public function preloadStockForProducts(array $products)
    {
        $ids = [];
        foreach ($products as $product) {
            $childIds = $this->getChildIds($product);
            $childIds = $childIds ?: [$product->getId()];
            $ids = array_merge($ids, $childIds);
        }

        $this->_getStockQty($ids);

        return $this;
    }

    /**
     * Get stock quantities using product ids
     *
     * @param  array $productIds
     * @return array
     */
    private function _getStockQty(array $productIds)
    {
        if (array_diff($productIds, array_keys($this->cachedQty))) {
            $criteria = $this->criteriaFactory->create();
            $criteria->setScopeFilter($this->stockConfiguration->getDefaultScopeId());
            $criteria->setProductsFilter($productIds);
            $items = $this->stockItemRepository->getList($criteria)->getItems();
            foreach ($items as $item) {
                $this->cachedQty[$item->getProductId()] = $item->getQty();
            }
        }

        return array_intersect_key($this->cachedQty, array_flip($productIds));
    }

    public function canShowProlabel($mode)
    {
        $groupId = (string)$this->session->getCustomerGroupId();
        $store = $this->storeManager->getStore();
        $isEnabled = !!$store->getConfig("prolabels/in_stock/{$mode}/active");
        $excludeGroups = explode(
            ',',
            $store->getConfig('prolabels/in_stock/exclude_customer_group')
        );

        return $isEnabled && !in_array($groupId, $excludeGroups);
    }
}
