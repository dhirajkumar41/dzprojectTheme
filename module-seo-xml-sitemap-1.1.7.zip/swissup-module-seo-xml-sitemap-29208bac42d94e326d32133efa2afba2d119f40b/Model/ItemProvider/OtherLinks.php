<?php

namespace Swissup\SeoXmlSitemap\Model\ItemProvider;

use Magento\Sitemap\Model\ItemProvider\ItemProviderInterface;
use Magento\Sitemap\Model\SitemapItemInterfaceFactory;
use Swissup\SeoHtmlSitemap\Model\LinkFactory;
use Swissup\SeoXmlSitemap\Helper\Data as Helper;

class OtherLinks implements ItemProviderInterface
{
    /**
     * @var SitemapItemInterfaceFactory
     */
    protected $itemFactory;

    /**
     * @var LinkFactory
     */
    protected $linkFactory;

    /**
     * @var Helper
     */
    protected $helper;

    /**
     * @param SitemapItemInterfaceFactory $itemFactory
     * @param LinkFactory                 $linkFactory
     * @param Helper                      $helper
     */
    public function __construct(
        SitemapItemInterfaceFactory $itemFactory,
        LinkFactory $linkFactory,
        Helper $helper
    ) {
        $this->itemFactory = $itemFactory;
        $this->linkFactory = $linkFactory;
        $this->helper = $helper;
    }

    /**
     * {@inheritdoc}
     */
    public function getItems($storeId)
    {
        $collection = $this->linkFactory->create()
            ->getCollection()
            ->addStoreFilter($storeId);
        $items = array_map(function ($item) use ($storeId) {
            return $this->itemFactory->create([
                'url' => $item->getUrl(),
                'updatedAt' => $item->getUpdateTime(),
                'images' => $item->getImages(),
                'priority' => $this->helper->getOtherPriority($storeId),
                'changeFrequency' => $this->helper->getOtherChangefreq($storeId),
            ]);
        }, $collection->getItems());

        return $items;
    }
}
