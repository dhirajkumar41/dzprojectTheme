<?php
namespace Swissup\Ajaxsearch\Model\Layer;

class Search extends \Magento\Catalog\Model\Layer\Search
{

}
