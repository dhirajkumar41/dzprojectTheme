var config = {
    map: {
        '*': {
            imageAssignment : 'Swissup_Easycatalogimg/js/image-assignment'
        }
    }
};
