<?php

namespace Swissup\Easybanner\Observer;

class RegisterCookies implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * Prepare forms
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $observer->getCollection()->addItemFromArray([
            'name' => 'easybanner',
            'description' => "Preserves the visitor's preferences and stats regarding shown popup blocks.",
            'group' => 'advertisement',
        ]);
    }
}
