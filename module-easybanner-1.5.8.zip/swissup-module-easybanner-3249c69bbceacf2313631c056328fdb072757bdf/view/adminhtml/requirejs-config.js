var config = {
    config: {
        mixins: {
            'Magento_Ui/js/lib/validation/rules': {
                'Swissup_Easybanner/js/validation/easybanner-validate-pattern': true
            }
        }
    }
};
