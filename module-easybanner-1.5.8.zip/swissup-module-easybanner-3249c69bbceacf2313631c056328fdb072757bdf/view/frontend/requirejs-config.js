var config = {
    map: {
        '*': {
            easybanner: 'Swissup_Easybanner/js/easybanner'
        }
    }
};
