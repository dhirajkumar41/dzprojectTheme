var config = {
    config: {
        mixins: {
            'Magento_Swatches/js/swatch-renderer': {
                'Swissup_SeoUrls/js/mixin/swatch-renderer': true
            }
        }
    }
};
