<?php

namespace Swissup\Highlight\Block;

use Magento\Framework\View\Element\Template;

class Wrapper extends Template
{
    protected $_template = 'Swissup_Highlight::block.phtml';
}
