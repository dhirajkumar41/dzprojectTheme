var config = {
    config: {
        mixins: {
            'Magento_Swatches/js/swatch-renderer': {
                'js/mixin/swatch-renderer/label-wrapper': true
            },
            'mage/accordion': {
                'js/mixin/accordion/layered-navigation-expanded': true
            }
        }
    }
};
