# Argento Stripes theme editor

Installation

```bash
cd <magento_root>
composer config repositories.swissup composer https://docs.swissuplabs.com/packages/
composer require swissup/module-theme-editor-argento-stripes --prefer-source
bin/magento module:enable Swissup_ThemeEditorArgentoStripes Swissup_Core
bin/magento setup:upgrade
```
