<?php
namespace Swissup\SeoHtmlSitemap\Model\Link\Locator;

interface LocatorInterface
{
    /**
     * @return \Swissup\SeoHtmlSitemap\Model\Link
     */
    public function getLink();
}
