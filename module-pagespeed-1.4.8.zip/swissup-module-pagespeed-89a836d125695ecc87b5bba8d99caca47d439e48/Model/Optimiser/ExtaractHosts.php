<?php
namespace Swissup\Pagespeed\Model\Optimiser;

class ExtaractHosts
{
    /**
     * @var array
     */
    private $hosts = [];

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(\Magento\Store\Model\StoreManagerInterface $storeManager)
    {
        $this->storeManager = $storeManager;
    }

    /**
     * @param DOMXPath $xpath
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function process($xpath)
    {
        //$xpath = $this->getDOMXPath($html);
        $hashId = false;
        if (function_exists('spl_object_hash')) {
            $hashId = spl_object_hash($xpath);
            if (isset($this->hosts[$hashId])) {
                return $this->hosts[$hashId];
            }
        }

        $templates = array(
            '//link'   => 'href',
            '//script' => 'src',
            '//img'    => 'src',
        );
        $urls = [];
        $baseUrl = $this->storeManager->getStore()->getBaseUrl();
        $baseUrlHost = parse_url($baseUrl, PHP_URL_HOST);

        foreach ($templates as $xpathString => $attribute) {
            $nodes = $xpath->query($xpathString);
            foreach ($nodes as $node) {
                $url = $node->getAttribute($attribute);
                $_url = parse_url($url, PHP_URL_HOST);
                if (!empty($_url) && false === strpos($url, $baseUrlHost)) {
                    $urls['//' . $_url] = $url;
                }
            }
        }
        if ($hashId !== false) {
            $this->hosts[$hashId] = $urls;
        }

        return $urls;
    }
}
