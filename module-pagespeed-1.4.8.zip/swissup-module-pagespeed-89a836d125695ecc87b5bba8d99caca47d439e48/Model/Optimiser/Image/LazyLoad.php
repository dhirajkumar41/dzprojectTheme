<?php
namespace Swissup\Pagespeed\Model\Optimiser\Image;

use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\App\Response\Http as ResponseHttp;
use Swissup\Pagespeed\Helper\Config;

class LazyLoad extends AbstractImage
{
    /**
     *
     * @var \Swissup\Pagespeed\Model\Optimiser\Preloader
     */
    private $preloader;

    /**
     *
     * @var \Swissup\Image\Helper\Dimensions
     */
    private $imageSize;

    /**
     * @param Config $config
     * @param \Magento\Framework\App\CacheInterface $cache
     * @param \Magento\Framework\App\Cache\StateInterface $cacheState
     * @param \Magento\Framework\Serialize\Serializer\Json $serializer
     * @param \Swissup\Pagespeed\Model\Optimiser\Preloader $preloader
     * @param \Swissup\Image\Helper\Dimensions $imageSize
     */
    public function __construct(
        Config $config,
        \Magento\Framework\App\CacheInterface $cache,
        \Magento\Framework\App\Cache\StateInterface $cacheState,
        \Magento\Framework\Serialize\Serializer\Json $serializer,
        \Swissup\Pagespeed\Model\Optimiser\Preloader $preloader,
        \Swissup\Image\Helper\Dimensions $imageSize
    ) {
        parent::__construct($config, $cache, $cacheState, $serializer);
        $this->preloader = $preloader;
        $this->imageSize = $imageSize;
    }

    /**
     *
     * @param string $src
     * @return boolean
     */
    protected function isIgnored($src)
    {
        return $this->config->isImageLazyLoadIgnored($src);
    }

    /**
     *
     * @return int
     */
    protected function getOffset()
    {
        $offset = $this->config->isMobile() ?
            $this->config->getLazyloadMobileOffset() : $this->config->getLazyloadOffset();
        $offset = $offset + 1;

        return $offset;
    }

    /**
     * Perform result postprocessing
     *
     * @param ResponseHttp $response
     * @return ResponseHttp
     */
    public function process(ResponseHttp $response = null)
    {
        if (!$this->config->isImageLazyLoadEnable() || $response === null) {
            return $response;
        }
        $html = $response->getBody();
        $images = $this->getImagesFromHtml($html);

        if (empty($images)) {
            return;
        }

        $offset = $this->getOffset();

        $preloadImages = [];
        foreach ($images as $image) {
            $imageHTML = $image;
            $node = $this->getDOMNodeFromImageHtml($imageHTML);

            $src = $node->getAttribute('src');
            $width = $node->getAttribute('width') ?: $this->imageSize->getWidth($src);
            $height = $node->getAttribute('height') ?: $this->imageSize->getHeight($src);

            $class = $node->getAttribute('class');
            if (strpos($class, 'xs-hide') !== false
                || strpos($class, 'sm-hide') !== false
            ) {
                // these images are invisible by default, don't lazyload them.
                continue;
            }

            $hasInjection = false;
            foreach (array('src', 'srcset') as $attrName) {
                $attrValue = $node->getAttribute($attrName);
                if (empty($attrValue) || $this->isIgnored($attrValue)) {
                    continue;
                }

                $dataAttrName = 'data-' . $attrName;
                $dataAttrValue = $node->getAttribute($dataAttrName);
                if (!empty($dataAttrValue)) {
                    continue;
                }

                $node->setAttribute($dataAttrName, $attrValue);

                $placeholder = sprintf(
                    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 %s %s'></svg>",
                    $width,
                    $height
                );
                $placeholder = 'data:image/svg+xml;base64,' . base64_encode($placeholder);

                if ($attrName === 'srcset') {
                    $sizesAttrValue = $node->getAttribute('sizes');
                    if (!empty($sizesAttrValue)) {
                        $placeholder = $placeholder . ' 1w';
                    }
                }

                $node->setAttribute($attrName, $placeholder);
                $hasInjection = true;
            }

            if ($hasInjection) {
                //add css class
                $class = $class . ' lazyload';
                $node->setAttribute('class', trim($class));

                //add alt for fix chrome width 0 (auto) bug
                $alt = $node->getAttribute('alt');
                if (empty($alt)) {
                    $node->setAttribute('alt', 'lazyload');
                }

                if (--$offset > 0) {
                    $src = $node->getAttribute('data-src');
                    $isParentPicture = $this->isParentTagPicture($html, $imageHTML);
                    if (!empty($src) && !$isParentPicture) {
                        $preloadImages[] = $src;
                    }
                    continue;
                }

                $_image = $this->getImageHtmlFromDOMNode($node);
                $html = str_replace($image, $_image, $html);
            }
        }

        $response->setBody($html);

        $this->preloader->push($response, $preloadImages, 'image', 'preload');

        return $response;
    }
}
