<?php

namespace Swissup\Pagespeed\Plugin\Block\Html\Header;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Asset\File\NotFoundException;
use Magento\Framework\View;

class CriticalCssPlugin
{
    /**
     * @var \Swissup\Pagespeed\Helper\Config
     */
    private $config;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * @var View\Layout
     */
    private $layout;

    /**
     * @var View\Page\Config
     */
    private $pageConfig;

    /**
     * @var Repository
     */
    private $assetRepo;

    /**
     * @param \Swissup\Pagespeed\Helper\Config        $config
     * @param \Magento\Framework\App\RequestInterface $request
     * @param View\Layout                             $layout
     * @param View\Page\Config                        $pageConfig
     * @param View\Asset\Repository                   $assetRepo
     */
    public function __construct(
        \Swissup\Pagespeed\Helper\Config $config,
        \Magento\Framework\App\RequestInterface $request,
        View\Layout $layout,
        View\Page\Config $pageConfig,
        View\Asset\Repository $assetRepo
    ) {
        $this->config = $config;
        $this->request = $request;
        $this->layout = $layout;
        $this->pageConfig = $pageConfig;
        $this->assetRepo = $assetRepo;
    }

    /**
     * Will return the currect page layout.
     *
     * @return string The current page layout.
     */
    private function getCurrentPageLayout()
    {
        $currentPageLayout = $this->pageConfig->getPageLayout();

        if (is_null($currentPageLayout))
        {
            return $this->layout->getUpdate()->getPageLayout();
        }

        return $currentPageLayout;
    }

    /**
     *
     * @return string
     */
    private function getFullActionName()
    {
        return $this->request->getFullActionName();
    }

    /**
     *
     * @param  \Magento\Theme\Block\Html\Header\CriticalCss $subject
     * @param  string $result
     * @return string
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetCriticalCssData(
        \Magento\Theme\Block\Html\Header\CriticalCss $subject,
        $result
    ) {
        if ($this->config->isCriticalCssThemeHanleMergeEnable()) {
            foreach ($this->getAssetNames() as $name) {
                try {
                    $asset = $this->assetRepo->createAsset(
                        'css/critical/' . $name,
                        ['_secure' => 'false']
                    );
                    $result .= $asset->getContent();
                    break;
                } catch (LocalizedException | NotFoundException $e) {
                    //
                }
            }
        }

        if ($this->config->isCriticalCssEnable()
            && $this->config->isUseCssCriticalPathEnable()
        ) {
            $configContent = $this->config->getDefaultCriticalCss();

            $result .= $configContent;
        }

        return $result;
    }

    /**
     * @return array
     */
    private function getAssetNames()
    {
        return [
            $this->getFullActionName(). '-' . $this->getCurrentPageLayout() . '.css',
            $this->getFullActionName() . '.css',
        ];
    }
}
