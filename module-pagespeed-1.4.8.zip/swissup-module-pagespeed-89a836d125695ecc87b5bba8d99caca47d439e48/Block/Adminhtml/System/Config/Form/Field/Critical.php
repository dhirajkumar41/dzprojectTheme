<?php

namespace Swissup\Pagespeed\Block\Adminhtml\System\Config\Form\Field;

use Swissup\Pagespeed\Block\Adminhtml\System\Config\Form\Field\StoreAbstract as Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class Critical extends Field
{
    /**
     * Retrieve element HTML markup
     *
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $url = $this->getStoreBaseUrl();
        $apiUrl = 'http://ci.swissuplabs.com/pagespeed/critical-css/generate?website=' . urlencode($url);

        return parent::_getElementHtml($element) . '<a href="' . $apiUrl . '" target="_blank" >Get your site critical css.</a>';
    }
}
