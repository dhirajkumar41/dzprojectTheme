<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Page;

class Duplicate extends \Swissup\Attributepages\Controller\Adminhtml\AbstractDuplicate
{
}
