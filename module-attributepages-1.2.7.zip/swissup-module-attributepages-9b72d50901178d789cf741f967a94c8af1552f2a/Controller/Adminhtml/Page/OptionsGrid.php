<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Page;

class OptionsGrid extends Options
{
}
