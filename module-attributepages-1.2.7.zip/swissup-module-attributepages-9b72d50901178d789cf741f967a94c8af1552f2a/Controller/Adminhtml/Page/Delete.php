<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Page;

class Delete extends \Swissup\Attributepages\Controller\Adminhtml\AbstractDelete
{
    /**
     * Admin resource
     */
    const ADMIN_RESOURCE = 'Swissup_Attributepages::page_delete';
}
