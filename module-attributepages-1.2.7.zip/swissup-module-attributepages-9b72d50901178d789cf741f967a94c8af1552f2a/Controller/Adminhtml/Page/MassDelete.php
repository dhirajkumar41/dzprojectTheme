<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Page;

/**
 * Class MassDelete
 */
class MassDelete extends \Swissup\Attributepages\Controller\Adminhtml\AbstractMassDelete
{
    /**
     * Admin resource
     */
    const ADMIN_RESOURCE = 'Swissup_Attributepages::page_delete';
}
