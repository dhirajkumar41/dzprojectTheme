<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Option;

/**
 * Class MassDelete
 */
class MassDelete extends \Swissup\Attributepages\Controller\Adminhtml\AbstractMassDelete
{
    /**
     * Admin resource
     */
    const ADMIN_RESOURCE = 'Swissup_Attributepages::option_delete';
}
