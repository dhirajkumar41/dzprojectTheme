<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Option;

class Duplicate extends \Swissup\Attributepages\Controller\Adminhtml\AbstractDuplicate
{
}
