<?php
namespace Swissup\Attributepages\Controller\Adminhtml\Option;

class Delete extends \Swissup\Attributepages\Controller\Adminhtml\AbstractDelete
{
    /**
     * Admin resource
     */
    const ADMIN_RESOURCE = 'Swissup_Attributepages::option_delete';
}
