<?php
namespace Swissup\Attributepages\Ui\Component\Listing\Column;

class AttributeoptionsActions extends AbstractActions
{
    /** Url path */
    const URL_PATH_EDIT = 'attributepages/option/edit';
    const URL_PATH_DELETE = 'attributepages/option/delete';
    const URL_PATH_DUPLICATE = 'attributepages/option/duplicate';
}
