<?php
namespace Swissup\Attributepages\Ui\Component\Listing\Column;

class AttributepagesActions extends AbstractActions
{
    /** Url path */
    const URL_PATH_EDIT = 'attributepages/page/edit';
    const URL_PATH_DELETE = 'attributepages/page/delete';
    const URL_PATH_DUPLICATE = 'attributepages/page/duplicate';
}
