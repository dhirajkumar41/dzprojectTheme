<?php
namespace Swissup\Attributepages\Block\Adminhtml\Page\Edit\Tab\Renderer;

use Magento\Framework\DataObject;

class Thumbnail extends \Swissup\Attributepages\Block\Adminhtml\Page\Edit\Tab\Renderer\Image
{
    protected $_type = 'thumbnail';
}
