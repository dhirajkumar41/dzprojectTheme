<?php

namespace Swissup\SeoPager\Plugin\View\Result;

use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\LayoutInterface;
use Magento\Framework\App\Response\Http as ResponseHttp;
use Swissup\SeoPager\Model\Filter\Title as TitleFilter;

class Page
{
    /**
     * @var LayoutInterface
     */
    private $layout;

    /**
     * @var TitleFilter
     */
    private $titleFilter;

    /**
     * @var \Swissup\SeoPager\Helper\Data
     */
    private $helper;

    /**
     * @param \Swissup\SeoPager\Helper\Data $helper
     * @param TitleFilter                   $titleFilter
     */
    public function __construct(
        \Swissup\SeoPager\Helper\Data $helper,
        LayoutInterface $layout,
        TitleFilter $titleFilter
    ) {
        $this->helper = $helper;
        $this->layout = $layout;
        $this->titleFilter = $titleFilter;
    }

    /**
     * Update page title according template from config (if possible).
     *
     * @param  ResultInterface $subject
     * @param  ResultInterface $result
     * @param  ResponseHttp    $response
     * @return ResultInterface
     */
    public function afterRenderResult(
        ResultInterface $subject,
        ResultInterface $result,
        ResponseHttp $response
    ) {
        if ($response === null) {
            return $result;
        }

        if (!$result instanceof \Magento\Framework\View\Result\Page) {
            return $result;
        }

        if ($this->helper->isEnabled()) {
            $html = $response->getBody();

            $block = $this->layout->getBlock('seo.pager.head.links');
            if ($block) {
                $html = str_replace(
                    '</head>',
                    $block->setTemplate('head/links.phtml')->toHtml() . "</head>",
                    $html
                );
            }

            if ($this->titleFilter->currentPageDirective() > 1) {
                preg_match("/<title>(.+)<\/title>/i", $html, $matches);
                if (isset($matches[1])) {
                    $title = $matches[1];
                    $object = new \Magento\Framework\DataObject(['title' => $title]);
                    $this->titleFilter->setScope($object);
                    $template = $this->helper->getTitleTemplate();
                    $html = str_replace(
                        "<title>{$title}</title>",
                        "<title>{$this->titleFilter->filter($template)}</title>",
                        $html
                    );
                }
            }

            $response->setBody($html);
        }

        return $result;
    }
}
